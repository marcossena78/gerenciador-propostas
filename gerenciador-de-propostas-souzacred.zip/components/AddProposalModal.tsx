import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import { Proposal, OperationType, ContratoNovoRefinProposal, PortabilidadeProposal, BaseProposal, ProposalStatus } from '../types'; // Added BaseProposal
import { formatCPF, generateId, formatBRL, formatInputAsCurrencyBR } from '../utils/formatting';
import { OPERATION_TYPE_OPTIONS, SHEET_NAME_CONTRATOS_NOVOS_REFIN, SHEET_NAME_PORTABILIDADE, BANCOS_OPTIONS, PROMOTORAS_OPTIONS, STATUS_OPTIONS_MODAL } from '../constants';

// Define the props for the modal
interface AddProposalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (proposal: Proposal, sheetName: string) => void;
  editingProposal: Proposal | null;
  activeSheetName: string;
}

const initialFormState = {
  id: '',
  numeroProposta: '',
  cpf: '',
  nomeCliente: '',
  tipoOperacao: '', 
  dataDigitacao: new Date().toISOString().split('T')[0], 
  promotora: PROMOTORAS_OPTIONS[0] === "Todas" ? PROMOTORAS_OPTIONS[1] : PROMOTORAS_OPTIONS[0] ,
  bancoProponente: BANCOS_OPTIONS[0] === "Todas" ? BANCOS_OPTIONS[1] : BANCOS_OPTIONS[0],
  valorParcela: 'R$ 0,00',
  valorContrato: 'R$ 0,00', 
  saldoDevedorPrevisto: 'R$ 0,00',
  liquidoPrevisto: 'R$ 0,00',
  saldoRetornado: 'R$ 0,00', 
  liquidoRecalculado: 'R$ 0,00', 
  statusProposta: STATUS_OPTIONS_MODAL.find(s => s.value !== "" && s.value !== ProposalStatus.CONCLUIDA)?.value || STATUS_OPTIONS_MODAL[1]?.value || '', // Ensure a default valid status
  observacoes: '',
  // Fields for Portabilidade specific data in modal if needed
  dataEnvioCip: '',
  dataRetornoCip: '',
};


const AddProposalModal: React.FC<AddProposalModalProps> = ({ isOpen, onClose, onSave, editingProposal, activeSheetName }) => {
  const [formData, setFormData] = useState<any>(initialFormState);
  const [isEditing, setIsEditing] = useState(false);
  const mainSheetOperations = [
    OperationType.NOVO,
    OperationType.REFINANCIAMENTO,
    OperationType.CARTAO_COM_SAQUE,
    OperationType.SAQUE_COMPLEMENTAR,
  ];


  useEffect(() => {
    if (isOpen) {
      if (editingProposal) {
        setIsEditing(true);
        const currentProposalData = { ...editingProposal }; // Make a mutable copy

        // Start with initialFormState and overlay with editingProposal data
        const dataForForm: any = {
          ...initialFormState,
          ...currentProposalData,
          id: currentProposalData.id,
          valorParcela: formatBRL(currentProposalData.valorParcela),
          observacoes: currentProposalData.observacoes || '',
          statusProposta: currentProposalData.statusProposta || initialFormState.statusProposta,
        };

        // Handle fields based on proposal type
        if ('dataDigitacao' in currentProposalData) {
            dataForForm.dataDigitacao = (currentProposalData as ContratoNovoRefinProposal | PortabilidadeProposal).dataDigitacao || initialFormState.dataDigitacao;
        }

        if (currentProposalData.tipoOperacao === OperationType.PORTABILIDADE) {
          const p = currentProposalData as PortabilidadeProposal;
          dataForForm.valorContrato = 'R$ 0,00';
          dataForForm.saldoDevedorPrevisto = formatBRL(p.saldoDevedorPrevisto);
          dataForForm.liquidoPrevisto = formatBRL(p.liquidoPrevisto);
          // Load saldoRetornado and liquidoRecalculado if editing Portabilidade
          dataForForm.saldoRetornado = formatBRL(p.saldoRetornado);
          dataForForm.liquidoRecalculado = formatBRL(p.liquidoRecalculado);
          dataForForm.dataEnvioCip = ''; // Hidden for Port op
          dataForForm.dataRetornoCip = ''; // Hidden for Port op
        } else if (mainSheetOperations.includes(currentProposalData.tipoOperacao as OperationType)) {
          const p = currentProposalData as ContratoNovoRefinProposal;
          dataForForm.valorContrato = formatBRL(p.valorContrato);
          dataForForm.saldoDevedorPrevisto = 'R$ 0,00';
          dataForForm.liquidoPrevisto = 'R$ 0,00';
          dataForForm.saldoRetornado = 'R$ 0,00';
          dataForForm.liquidoRecalculado = 'R$ 0,00';
          dataForForm.dataEnvioCip = '';
          dataForForm.dataRetornoCip = '';
        } else { // Other operation types or empty, clear all conditional fields
          dataForForm.valorContrato = 'R$ 0,00';
          dataForForm.saldoDevedorPrevisto = 'R$ 0,00';
          dataForForm.liquidoPrevisto = 'R$ 0,00';
          dataForForm.saldoRetornado = 'R$ 0,00';
          dataForForm.liquidoRecalculado = 'R$ 0,00';
          dataForForm.dataEnvioCip = '';
          dataForForm.dataRetornoCip = '';
        }
        setFormData(dataForForm);
      } else { // Adding new proposal
        setIsEditing(false);
        const baseData: any = {
          ...initialFormState,
          id: generateId(),
          promotora: PROMOTORAS_OPTIONS.find(p => p !== "Todas") || '',
          bancoProponente: BANCOS_OPTIONS.find(b => b !== "Todos") || '',
          statusProposta: initialFormState.statusProposta,
          dataDigitacao: new Date().toISOString().split('T')[0],
        };
        
        let defaultOpType = '';
        let specificFields = {};

        if (activeSheetName === SHEET_NAME_CONTRATOS_NOVOS_REFIN) {
            defaultOpType = OperationType.NOVO; // Default to 'Novo'
             specificFields = { 
                valorContrato: 'R$ 0,00',
                saldoDevedorPrevisto: 'R$ 0,00',
                liquidoPrevisto: 'R$ 0,00',
                saldoRetornado: 'R$ 0,00',
                liquidoRecalculado: 'R$ 0,00',
                dataEnvioCip: '',
                dataRetornoCip: '',
            };
        } else if (activeSheetName === SHEET_NAME_PORTABILIDADE) {
            defaultOpType = OperationType.PORTABILIDADE; // Default to 'Portabilidade'
            specificFields = { 
                valorContrato: 'R$ 0,00',
                saldoDevedorPrevisto: 'R$ 0,00', 
                liquidoPrevisto: 'R$ 0,00',
                saldoRetornado: 'R$ 0,00', // Hidden for new Port, so R$ 0,00
                liquidoRecalculado: 'R$ 0,00', // Hidden for new Port, so R$ 0,00
                dataEnvioCip: '',
                dataRetornoCip: '',
            };
        } else { // Fallback if activeSheetName is something unexpected
             specificFields = {
                valorContrato: 'R$ 0,00',
                saldoDevedorPrevisto: 'R$ 0,00',
                liquidoPrevisto: 'R$ 0,00',
                saldoRetornado: 'R$ 0,00',
                liquidoRecalculado: 'R$ 0,00',
                dataEnvioCip: '',
                dataRetornoCip: '',
            };
        }
        setFormData({ ...baseData, tipoOperacao: defaultOpType, ...specificFields });
      }
    }
  }, [editingProposal, isOpen, activeSheetName]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    let newFormData = { ...formData };
    const monetaryFields = ['valorParcela', 'valorContrato', 'saldoDevedorPrevisto', 'liquidoPrevisto', 'saldoRetornado', 'liquidoRecalculado'];

    if (name === 'cpf') {
      newFormData[name] = formatCPF(value);
    } else if (name === 'nomeCliente') {
      newFormData[name] = value.toUpperCase();
    } else if (monetaryFields.includes(name)) {
      newFormData[name] = formatInputAsCurrencyBR(value);
    }
     else {
      newFormData[name] = value;
    }

    if (name === 'tipoOperacao') {
      if (value === OperationType.PORTABILIDADE) {
        newFormData.valorContrato = 'R$ 0,00'; 
        // saldoDevedorPrevisto & liquidoPrevisto will be shown by showField
        if (!isEditing) { // Only clear for new proposals, for editing they are loaded if op type was already Port.
          newFormData.saldoRetornado = 'R$ 0,00'; 
          newFormData.liquidoRecalculado = 'R$ 0,00'; 
        }
        newFormData.dataEnvioCip = ''; 
        newFormData.dataRetornoCip = ''; 
      } else if (mainSheetOperations.includes(value as OperationType)) {
        // valorContrato will be shown by showField
        newFormData.saldoDevedorPrevisto = 'R$ 0,00'; 
        newFormData.liquidoPrevisto = 'R$ 0,00'; 
        newFormData.saldoRetornado = 'R$ 0,00'; 
        newFormData.liquidoRecalculado = 'R$ 0,00'; 
        newFormData.dataEnvioCip = ''; 
        newFormData.dataRetornoCip = '';
      } else { // Other operation types (e.g. empty)
        newFormData.valorContrato = 'R$ 0,00';
        newFormData.saldoDevedorPrevisto = 'R$ 0,00';
        newFormData.liquidoPrevisto = 'R$ 0,00';
        newFormData.saldoRetornado = 'R$ 0,00'; 
        newFormData.liquidoRecalculado = 'R$ 0,00'; 
        newFormData.dataEnvioCip = '';
        newFormData.dataRetornoCip = '';
      }
    }
    
    setFormData(newFormData);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.numeroProposta || !formData.cpf || !formData.nomeCliente || !formData.tipoOperacao) {
      alert('Por favor, preencha todos os campos obrigatórios (*).\nCertifique-se que "Tipo de Operação" está selecionado.');
      return;
    }
    
    let finalFormData = { ...formData };
    
    // Determine target sheet based on operation type
    let targetSheetName = activeSheetName; 

    if (mainSheetOperations.includes(finalFormData.tipoOperacao as OperationType)) {
        targetSheetName = SHEET_NAME_CONTRATOS_NOVOS_REFIN;
    } else if (finalFormData.tipoOperacao === OperationType.PORTABILIDADE) {
        targetSheetName = SHEET_NAME_PORTABILIDADE;
    }
    
    // Clear fields based on final tipoOperacao, ensuring consistency before saving
    if (finalFormData.tipoOperacao === OperationType.PORTABILIDADE) {
        finalFormData.valorContrato = 'R$ 0,00';
        if (!isEditing) { // If adding new port, these are hidden and should be R$ 0,00
            finalFormData.saldoRetornado = 'R$ 0,00';
            finalFormData.liquidoRecalculado = 'R$ 0,00';
        }
        // If editing, saldoRetornado & liquidoRecalculado come from formData
        finalFormData.dataEnvioCip = ''; 
        finalFormData.dataRetornoCip = '';
    } else if (mainSheetOperations.includes(finalFormData.tipoOperacao as OperationType)) {
        finalFormData.saldoDevedorPrevisto = 'R$ 0,00';
        finalFormData.liquidoPrevisto = 'R$ 0,00';
        finalFormData.saldoRetornado = 'R$ 0,00'; 
        finalFormData.liquidoRecalculado = 'R$ 0,00'; 
        finalFormData.dataEnvioCip = '';
        finalFormData.dataRetornoCip = '';
    } else { 
        finalFormData.valorContrato = 'R$ 0,00';
        finalFormData.saldoDevedorPrevisto = 'R$ 0,00';
        finalFormData.liquidoPrevisto = 'R$ 0,00';
        finalFormData.saldoRetornado = 'R$ 0,00'; 
        finalFormData.liquidoRecalculado = 'R$ 0,00'; 
        finalFormData.dataEnvioCip = '';
        finalFormData.dataRetornoCip = '';
    }

    const baseProposalData: Omit<BaseProposal, 'tipoOperacao'> & { tipoOperacao: OperationType } = { 
      id: finalFormData.id || generateId(),
      numeroProposta: finalFormData.numeroProposta,
      cpf: finalFormData.cpf,
      nomeCliente: finalFormData.nomeCliente,
      tipoOperacao: finalFormData.tipoOperacao as OperationType,
      promotora: finalFormData.promotora,
      bancoProponente: finalFormData.bancoProponente,
      valorParcela: finalFormData.valorParcela, 
      statusProposta: finalFormData.statusProposta,
      observacoes: finalFormData.observacoes,
    };

    let proposalData: Proposal;

    if (targetSheetName === SHEET_NAME_CONTRATOS_NOVOS_REFIN) {
      proposalData = {
        ...baseProposalData,
        dataDigitacao: finalFormData.dataDigitacao,
        valorContrato: finalFormData.valorContrato, 
      } as ContratoNovoRefinProposal;
    } else if (targetSheetName === SHEET_NAME_PORTABILIDADE) { 
       let dataEnvioCipValue = ''; 
       if (finalFormData.tipoOperacao === OperationType.PORTABILIDADE && finalFormData.dataDigitacao) {
         dataEnvioCipValue = finalFormData.dataDigitacao; 
       } else {
         dataEnvioCipValue = finalFormData.dataEnvioCip;
       }
       
       proposalData = {
        ...baseProposalData,
        dataDigitacao: finalFormData.dataDigitacao, 
        dataEnvioCip: dataEnvioCipValue, 
        dataRetornoCip: finalFormData.dataRetornoCip, 
        saldoDevedorPrevisto: finalFormData.saldoDevedorPrevisto,
        liquidoPrevisto: finalFormData.liquidoPrevisto,
        saldoRetornado: finalFormData.saldoRetornado, 
        liquidoRecalculado: finalFormData.liquidoRecalculado,
      } as PortabilidadeProposal;
    } else {
        console.warn("Saving to an unexpected sheet structure based on targetSheetName:", targetSheetName, ". Defaulting to ContratoNovoRefin structure.");
        proposalData = { 
            ...baseProposalData,
            dataDigitacao: finalFormData.dataDigitacao, 
            valorContrato: finalFormData.valorContrato,
        } as ContratoNovoRefinProposal; 
    }
    onSave(proposalData, targetSheetName);
    onClose(); 
  };
  
 const showField = (fieldName: string): boolean => {
    const opType = formData.tipoOperacao;

    if (fieldName === 'saldoDevedorPrevisto' || fieldName === 'liquidoPrevisto') {
        return opType === OperationType.PORTABILIDADE;
    }

    if (fieldName === 'valorContrato') {
        return (
            opType === OperationType.NOVO ||
            opType === OperationType.REFINANCIAMENTO ||
            opType === OperationType.CARTAO_COM_SAQUE ||
            opType === OperationType.SAQUE_COMPLEMENTAR
        );
    }
    
    if (fieldName === 'saldoRetornado' || fieldName === 'liquidoRecalculado') {
        return isEditing && opType === OperationType.PORTABILIDADE;
    }

    if (opType === OperationType.PORTABILIDADE) {
        if (
            fieldName === 'dataEnvioCip' ||
            fieldName === 'dataRetornoCip'
            // saldoRetornado & liquidoRecalculado handled above
        ) {
            return false;
        }
    }
    
    if (fieldName === 'dataDigitacao') { // Data Digitação is always shown if an operation type is selected, or if no op type and on a specific sheet
        if (opType) return true;
        if (!opType && (activeSheetName === SHEET_NAME_CONTRATOS_NOVOS_REFIN || activeSheetName === SHEET_NAME_PORTABILIDADE)) return true;
    }

    // Default for fields not explicitly handled above and not generic:
    // dataEnvioCip, dataRetornoCip for non-Port op types
    if (
        (fieldName === 'dataEnvioCip' || fieldName === 'dataRetornoCip') &&
        opType && opType !== OperationType.PORTABILIDADE
    ) {
        return false; 
    }
    
    return false; // By default, hide fields unless explicitly shown
};


  return (
    <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={isEditing ? 'Editar Proposta' : 'Adicionar Nova Proposta'}
        titleIcon={isEditing ? "fas fa-edit" : "fas fa-plus-circle"}
        size="lg"
        footer={
            <>
            <button type="button" onClick={onClose} className="btn-secondary-modal">
                <i className="fas fa-times mr-2"></i>Cancelar
            </button>
            <button type="submit" form="addProposalForm" className="btn-primary-modal">
                <i className="fas fa-save mr-2"></i>Salvar
            </button>
            </>
        }
    >
      <form id="addProposalForm" onSubmit={handleSubmit}>
        <div className="grid grid-cols-6 gap-x-4 gap-y-5 p-3">

            <div className="col-span-6 sm:col-span-3">
                <label className="block text-sm font-medium text-gray-700">Tipo de Operação *</label>
                <select name="tipoOperacao" value={formData.tipoOperacao} onChange={handleChange} required className="mt-1 block w-full input-style">
                {OPERATION_TYPE_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                </select>
            </div>

            {showField('dataDigitacao') && (
                <div className="col-span-6 sm:col-span-3">
                    <label className="block text-sm font-medium text-gray-700">Data Digitação</label>
                    <input type="date" name="dataDigitacao" value={formData.dataDigitacao || ''} onChange={handleChange} className="mt-1 block w-full input-style" />
                </div>
            )}
            
            <div className="col-span-6 sm:col-span-3">
                <label className="block text-sm font-medium text-gray-700">Número da Proposta *</label>
                <input type="text" name="numeroProposta" value={formData.numeroProposta} onChange={handleChange} required className="mt-1 block w-full input-style" />
            </div>
            <div className="col-span-6 sm:col-span-3">
                <label className="block text-sm font-medium text-gray-700">CPF *</label>
                <input type="text" name="cpf" value={formData.cpf} onChange={handleChange} required className="mt-1 block w-full input-style" maxLength={14} />
            </div>

            <div className="col-span-6">
                <label className="block text-sm font-medium text-gray-700">Nome do Cliente *</label>
                <input type="text" name="nomeCliente" value={formData.nomeCliente} onChange={handleChange} required className="mt-1 block w-full input-style" />
            </div>

            <div className="col-span-6 sm:col-span-3">
                <label className="block text-sm font-medium text-gray-700">Banco</label>
                <select name="bancoProponente" value={formData.bancoProponente} onChange={handleChange} className="mt-1 block w-full input-style">
                {BANCOS_OPTIONS.filter(opt => opt !== "Todos").map(banco => <option key={banco} value={banco}>{banco}</option>)}
                </select>
            </div>
            <div className="col-span-6 sm:col-span-3">
                <label className="block text-sm font-medium text-gray-700">Promotora</label>
                <select name="promotora" value={formData.promotora} onChange={handleChange} className="mt-1 block w-full input-style">
                {PROMOTORAS_OPTIONS.filter(opt => opt !== "Todos").map(prom => <option key={prom} value={prom}>{prom}</option>)}
                </select>
            </div>
            
            {showField('dataEnvioCip') && (
                 <div className="col-span-6 sm:col-span-3">
                    <label className="block text-sm font-medium text-gray-700">Data Envio CIP</label>
                    <input type="date" name="dataEnvioCip" value={formData.dataEnvioCip || ''} onChange={handleChange} className="mt-1 block w-full input-style" />
                </div>
            )}
            {showField('dataRetornoCip') && (
                 <div className="col-span-6 sm:col-span-3">
                    <label className="block text-sm font-medium text-gray-700">Data Retorno CIP</label>
                    <input type="date" name="dataRetornoCip" value={formData.dataRetornoCip || ''} onChange={handleChange} className="mt-1 block w-full input-style" />
                </div>
            )}
            {showField('saldoDevedorPrevisto') && (
                <div className="col-span-6 sm:col-span-3">
                    <label className="block text-sm font-medium text-gray-700">Saldo Devedor Previsto</label>
                    <input type="text" name="saldoDevedorPrevisto" value={formData.saldoDevedorPrevisto} onChange={handleChange} className="mt-1 block w-full input-style" placeholder="R$ 0,00"/>
                </div>
            )}
            {showField('liquidoPrevisto') && (
                <div className="col-span-6 sm:col-span-3">
                    <label className="block text-sm font-medium text-gray-700">Líquido Previsto</label>
                    <input type="text" name="liquidoPrevisto" value={formData.liquidoPrevisto} onChange={handleChange} className="mt-1 block w-full input-style" placeholder="R$ 0,00"/>
                </div>
            )}
            {showField('saldoRetornado') && (
                <div className="col-span-6 sm:col-span-3">
                    <label className="block text-sm font-medium text-gray-700">Saldo Retornado</label>
                    <input type="text" name="saldoRetornado" value={formData.saldoRetornado} onChange={handleChange} className="mt-1 block w-full input-style" placeholder="R$ 0,00"/>
                </div>
            )}
            {showField('liquidoRecalculado') && (
                <div className="col-span-6 sm:col-span-3">
                    <label className="block text-sm font-medium text-gray-700">Líquido Recalculado</label>
                    <input type="text" name="liquidoRecalculado" value={formData.liquidoRecalculado} onChange={handleChange} className="mt-1 block w-full input-style" placeholder="R$ 0,00"/>
                </div>
            )}

            {showField('valorContrato') && (
              <div className="col-span-6 sm:col-span-3">
                  <label className="block text-sm font-medium text-gray-700">Valor do Contrato</label>
                  <input type="text" name="valorContrato" value={formData.valorContrato} onChange={handleChange} className="mt-1 block w-full input-style" placeholder="R$ 0,00"/>
              </div>
            )}
            
            <div className={`col-span-6 sm:col-span-3 ${
                (showField('valorContrato') || formData.tipoOperacao === OperationType.PORTABILIDADE) ? '' : 'sm:col-start-1' 
            }`}>
                <label className="block text-sm font-medium text-gray-700">Valor da Parcela</label>
                <input type="text" name="valorParcela" value={formData.valorParcela} onChange={handleChange} className="mt-1 block w-full input-style" placeholder="R$ 0,00"/>
            </div>

            <div className="col-span-6 sm:col-span-3">
                <label className="block text-sm font-medium text-gray-700">Status</label>
                <select name="statusProposta" value={formData.statusProposta} onChange={handleChange} className="mt-1 block w-full input-style">
                {STATUS_OPTIONS_MODAL.filter(s => s.value !== "").map(status => <option key={status.value} value={status.value}>{status.label}</option>)}
                </select>
            </div>
             <div className="col-span-6">
                <label className="block text-sm font-medium text-gray-700">Observações</label>
                <textarea name="observacoes" value={formData.observacoes} onChange={handleChange} rows={3} className="mt-1 block w-full input-style"></textarea>
            </div>
        </div>
      </form>
      <style>{`
        .input-style {
          appearance: none;
          background-color: #fff;
          border-color: #d1d5db; /* gray-300 */
          border-width: 1px;
          border-radius: 0.375rem; /* rounded-md */
          padding: 0.5rem 0.75rem; /* py-2 px-3 */
          font-size: 0.875rem; /* sm:text-sm */
          line-height: 1.25rem;
          box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05); /* shadow-sm */
        }
        .input-style:focus {
          outline: 2px solid transparent;
          outline-offset: 2px;
          border-color: #4f46e5; /* indigo-500 */
          box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.3); /* focus:ring-indigo-500 with opacity */
        }
        select.input-style {
          background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e");
          background-position: right 0.5rem center;
          background-repeat: no-repeat;
          background-size: 1.5em 1.5em;
          padding-right: 2.5rem;
        }
        .btn-primary-modal {
            background-color: #0D6EFD; color: white; font-weight: 600; padding: 0.5rem 1rem; border-radius: 0.375rem; box-shadow: 0 1px 2px 0 rgba(0,0,0,0.05);
        }
        .btn-primary-modal:hover {
            background-color: #0B5ED7;
        }
        .btn-secondary-modal {
            background-color: #6C757D; color: white; font-weight: 600; padding: 0.5rem 1rem; border-radius: 0.375rem; box-shadow: 0 1px 2px 0 rgba(0,0,0,0.05);
        }
        .btn-secondary-modal:hover {
            background-color: #5A6268;
        }
      `}</style>
    </Modal>
  );
};

export default AddProposalModal;