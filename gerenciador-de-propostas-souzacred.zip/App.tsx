
import React, { useState, useEffect, useCallback, useMemo } from 'react'; // Added useMemo
import Header from './components/Header';
import FilterBar from './components/FilterBar';
import ProposalTabs from './components/ProposalTabs';
import ProposalTable from './components/ProposalTable';
import AddProposalModal from './components/AddProposalModal';
import StatusModal from './components/StatusModal';
import ExportDropdown from './components/ExportDropdown';
import { Proposal, SheetData, Filters, ContratoNovoRefinProposal, PortabilidadeProposal, OperationType, ProposalStatus, NotificationMessage } from './types';
import { SHEET_NAME_CONTRATOS_NOVOS_REFIN, SHEET_NAME_PORTABILIDADE, SHEET_NAME_CONTRATOS_PAGOS, SHEET_NAME_PORTABILIDADES_PAGAS, SHEET_NAME_SALDOS_NAO_RETORNADOS, INITIAL_SHEET_NAMES } from './constants';
import { generateId, formatBRL } from './utils/formatting'; 

// Initial Mock Data
const initialProposalsData: SheetData = {
  [SHEET_NAME_CONTRATOS_NOVOS_REFIN]: [
    { 
      id: generateId(), dataDigitacao: '2023-01-15', numeroProposta: 'CNREFIN001', cpf: '111.111.111-11', nomeCliente: 'JOÃO DA SILVA', tipoOperacao: OperationType.REFINANCIAMENTO, promotora: 'PROMOTORA A', bancoProponente: 'BANCO PAN', valorParcela: formatBRL('250.00'), valorContrato: formatBRL('10000.00'), statusProposta: ProposalStatus.APROVADA_BANCO, rowClass: 'bg-green-50', observacoes: 'Cliente VIP' 
    } as ContratoNovoRefinProposal,
    { 
      id: generateId(), dataDigitacao: '2023-03-10', numeroProposta: 'CNREFIN002', cpf: '222.222.222-22', nomeCliente: 'MARIA OLIVEIRA', tipoOperacao: OperationType.NOVO, promotora: 'PROMOTORA B', bancoProponente: 'C6 BANK', valorParcela: formatBRL('350.00'), valorContrato: formatBRL('15000.00'), statusProposta: ProposalStatus.AGUARDANDO_AVERBACAO, observacoes: ''
    } as ContratoNovoRefinProposal,
     { 
      id: generateId(), dataDigitacao: '2023-03-12', numeroProposta: 'CNREFIN003', cpf: '555.555.555-55', nomeCliente: 'PEDRO ALMEIDA', tipoOperacao: OperationType.NOVO, promotora: 'PROMOTORA C', bancoProponente: 'BANCO SAFRA', valorParcela: formatBRL('450.00'), valorContrato: formatBRL('25000.00'), statusProposta: ProposalStatus.PAGO, observacoes: 'Contrato antigo pago para teste de migração'
    } as ContratoNovoRefinProposal,
  ],
  [SHEET_NAME_PORTABILIDADE]: [
    { 
      id: generateId(), 
      dataDigitacao: '2023-02-10', 
      dataEnvioCip: '2023-02-11',
      dataRetornoCip: '2023-02-15',
      numeroProposta: 'PORT001', 
      cpf: '333.333.333-33', 
      nomeCliente: 'CARLOS PEREIRA', 
      tipoOperacao: OperationType.PORTABILIDADE, 
      bancoProponente: 'ITAU BMG', 
      promotora: 'PROMOTORA VIP', 
      valorParcela: formatBRL('180.00'), 
      saldoDevedorPrevisto: formatBRL('8000.00'), 
      liquidoPrevisto: formatBRL('7800.00'), 
      saldoRetornado: formatBRL('7950.00'),
      liquidoRecalculado: formatBRL('7750.00'),
      statusProposta: ProposalStatus.AGUARDANDO_SALDO,
      observacoes: 'Aguardando retorno do saldo do banco X.'
    } as PortabilidadeProposal,
    { 
      id: generateId(), 
      dataDigitacao: '2023-04-15', 
      dataEnvioCip: '2023-04-16',
      dataRetornoCip: '', 
      numeroProposta: 'PORT002', 
      cpf: '444.444.444-44', 
      nomeCliente: 'ANA SOUZA', 
      tipoOperacao: OperationType.PORTABILIDADE,
      bancoProponente: 'DAYCOVAL', 
      promotora: 'PROMOTORA A', 
      valorParcela: formatBRL('420.00'), 
      saldoDevedorPrevisto: formatBRL('20000.00'), 
      liquidoPrevisto: formatBRL('19500.00'), 
      saldoRetornado: formatBRL('19800.00'), 
      liquidoRecalculado: formatBRL('19300.00'),
      statusProposta: ProposalStatus.SALDO_RETORNADO, 
      rowClass: 'bg-blue-50',
      observacoes: 'Saldo retornado, pendente aceite cliente.'
    } as PortabilidadeProposal,
     { 
      id: generateId(), 
      dataDigitacao: '2023-05-20', 
      dataEnvioCip: '2023-05-21',
      dataRetornoCip: '2023-05-25',
      numeroProposta: 'PORT003', 
      cpf: '666.666.666-66', 
      nomeCliente: 'RITA MOREIRA', 
      tipoOperacao: OperationType.PORTABILIDADE, 
      bancoProponente: 'BANCO BMG', 
      promotora: 'PROMOTORA C', 
      valorParcela: formatBRL('300.00'), 
      saldoDevedorPrevisto: formatBRL('12000.00'), 
      liquidoPrevisto: formatBRL('11800.00'), 
      saldoRetornado: formatBRL('11900.00'),
      liquidoRecalculado: formatBRL('11700.00'),
      statusProposta: ProposalStatus.PAGO, // For testing migration (will not auto-migrate now with new rule)
      observacoes: 'Portabilidade paga, teste de migração.'
    } as PortabilidadeProposal,
    { 
      id: generateId(), 
      dataDigitacao: '2023-06-01', 
      dataEnvioCip: '2023-06-02',
      dataRetornoCip: '',
      numeroProposta: 'PORT004', 
      cpf: '777.777.777-77', 
      nomeCliente: 'LUCAS GOMES', 
      tipoOperacao: OperationType.PORTABILIDADE, 
      bancoProponente: 'BANCO SAFRA', 
      promotora: 'PROMOTORA B', 
      valorParcela: formatBRL('220.00'), 
      saldoDevedorPrevisto: formatBRL('9500.00'), 
      liquidoPrevisto: formatBRL('9300.00'), 
      saldoRetornado: '',
      liquidoRecalculado: '',
      statusProposta: ProposalStatus.AGUARDANDO_SALDO,
      observacoes: 'Aguardando saldo para teste de Não Retornado.'
    } as PortabilidadeProposal,
  ],
  [SHEET_NAME_CONTRATOS_PAGOS]: [],
  [SHEET_NAME_PORTABILIDADES_PAGAS]: [],
  [SHEET_NAME_SALDOS_NAO_RETORNADOS]: [] // Initialize new sheet
};

const App: React.FC = () => {
  const [proposalsBySheet, setProposalsBySheet] = useState<SheetData>(initialProposalsData);
  const [activeSheetName, setActiveSheetName] = useState<string>(INITIAL_SHEET_NAMES[0]);
  const [filters, setFilters] = useState<Filters>({ nomeCliente: '', cpf: '', banco: '', promotora: '' });

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProposal, setEditingProposal] = useState<Proposal | null>(null);

  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false);
  const [statusChangeTarget, setStatusChangeTarget] = useState<{ proposalId: string; sheetName: string; currentStatus?: string; currentObservations?: string } | null>(null);
  
  const [notifications, setNotifications] = useState<NotificationMessage[]>([]);

  const addNotification = useCallback((type: NotificationMessage['type'], message: string) => {
    const newNotification = { id: generateId(), type, message };
    setNotifications(prev => [newNotification, ...prev.slice(0,2)]); // Keep max 3 notifications
    setTimeout(() => {
      setNotifications(prevNotifications => prevNotifications.filter(n => n.id !== newNotification.id));
    }, 5000);
  }, []); 

  const displayedProposals = useMemo(() => {
    const currentSheetProposals = proposalsBySheet[activeSheetName] || [];
    if (!filters.nomeCliente && !filters.cpf && !filters.banco && !filters.promotora) {
      return currentSheetProposals;
    }
    return currentSheetProposals.filter(p => {
      const nomeClienteMatch = !filters.nomeCliente || p.nomeCliente.toLowerCase().includes(filters.nomeCliente.toLowerCase());
      const cpfMatch = !filters.cpf || p.cpf.includes(filters.cpf);
      const bancoMatch = !filters.banco || p.bancoProponente === filters.banco;
      const promotoraMatch = !filters.promotora || p.promotora === filters.promotora;
      return nomeClienteMatch && cpfMatch && bancoMatch && promotoraMatch;
    });
  }, [proposalsBySheet, activeSheetName, filters]);

  const handleFilterChange = <K extends keyof Filters>(key: K, value: Filters[K]) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleApplyFilters = () => {
    console.log("Apply filters button clicked. Filters are live.");
  };

  const handleClearFilters = () => {
    setFilters({ nomeCliente: '', cpf: '', banco: '', promotora: '' });
  };

  const handleAddOrUpdateProposal = useCallback((proposal: Proposal, sheetName: string) => {
    setProposalsBySheet(prev => {
      const sheetProposals = [...(prev[sheetName] || [])];
      const existingIndex = sheetProposals.findIndex(p => p.id === proposal.id);
      if (existingIndex > -1) {
        sheetProposals[existingIndex] = proposal; 
         addNotification('success', `Proposta ${proposal.numeroProposta} atualizada com sucesso!`);
      } else {
        sheetProposals.unshift(proposal); // Add new proposals to the top
        addNotification('success', `Proposta ${proposal.numeroProposta} adicionada com sucesso!`);
      }
      return { ...prev, [sheetName]: sheetProposals };
    });
    setEditingProposal(null);
    setIsAddModalOpen(false);
  }, [addNotification]);
  
  const handleEditProposal = useCallback((proposal: Proposal) => {
    let proposalToEdit = { ...proposal }; 
    setEditingProposal(proposalToEdit);
    setIsAddModalOpen(true);
  }, []);

  const handleDeleteProposal = useCallback((proposalId: string, sheetName: string) => {
    const proposalToDelete = (proposalsBySheet[sheetName] || []).find(p => p.id === proposalId);
    if (!proposalToDelete) {
      addNotification('error', 'Erro: Proposta não encontrada para exclusão.');
      return;
    }

    const confirmDelete = window.confirm(`Tem certeza que deseja excluir a proposta "${proposalToDelete.numeroProposta}" de ${proposalToDelete.nomeCliente}? Esta ação não pode ser desfeita.`);
    if (confirmDelete) {
      setProposalsBySheet(prev => {
        const currentSheetProposals = prev[sheetName] || [];
        const updatedSheetProposals = currentSheetProposals.filter(p => p.id !== proposalId);
        return { ...prev, [sheetName]: updatedSheetProposals };
      });
      addNotification('warning', `Proposta ${proposalToDelete.numeroProposta} foi excluída.`);
    }
  }, [proposalsBySheet, addNotification]);

  const handleOpenStatusModal = useCallback((proposalId: string, sheetName: string) => {
     const proposal = (proposalsBySheet[sheetName] || []).find(p => p.id === proposalId);
     if (proposal) {
        setStatusChangeTarget({ proposalId, sheetName, currentStatus: proposal.statusProposta, currentObservations: proposal.observacoes });
        setIsStatusModalOpen(true);
     }
  }, [proposalsBySheet]);

  const handleStatusChangeSave = useCallback((newStatus: string, observations: string, action?: 'delete_proposal' | 'nao_retornado' | 'retornado') => {
    if (!statusChangeTarget) return;
    const { proposalId, sheetName } = statusChangeTarget;

    if (action === 'delete_proposal') { 
        handleDeleteProposal(proposalId, sheetName);
        setIsStatusModalOpen(false);
        setStatusChangeTarget(null);
        return;
    }
      
    setProposalsBySheet(prev => {
      const newState = { ...prev }; 
      let sourceSheetProposals = [...(newState[sheetName] || [])];
      const proposalIndex = sourceSheetProposals.findIndex(p => p.id === proposalId);

      if (proposalIndex === -1) {
        addNotification('error', `Proposta não encontrada para atualização de status.`);
        return prev; 
      }

      const proposalToUpdate = { ...sourceSheetProposals[proposalIndex] };
      // newStatus is already correctly set by StatusModal if 'retornado' or 'nao_retornado' action
      const effectiveNewStatus = newStatus || proposalToUpdate.statusProposta; 

      if (sheetName === SHEET_NAME_PORTABILIDADE && action === 'retornado') {
        proposalToUpdate.statusProposta = ProposalStatus.SALDO_RETORNADO;
        proposalToUpdate.observacoes = observations;
        
        const p = proposalToUpdate as PortabilidadeProposal;
        if (!p.dataRetornoCip) {
            p.dataRetornoCip = new Date().toISOString().split('T')[0];
        }

        newState[sheetName] = sourceSheetProposals.filter(prop => prop.id !== proposalId);
        
        const paidPortabilidadeSheetProposals = [...(newState[SHEET_NAME_PORTABILIDADES_PAGAS] || [])];
        paidPortabilidadeSheetProposals.unshift(proposalToUpdate); 
        newState[SHEET_NAME_PORTABILIDADES_PAGAS] = paidPortabilidadeSheetProposals;

        addNotification('success', `Proposta ${proposalToUpdate.numeroProposta} movida para ${SHEET_NAME_PORTABILIDADES_PAGAS}.`);
      
      } else if (sheetName === SHEET_NAME_PORTABILIDADE && action === 'nao_retornado') {
        proposalToUpdate.statusProposta = ProposalStatus.SALDO_NAO_RETORNADO;
        proposalToUpdate.observacoes = observations;

        newState[sheetName] = sourceSheetProposals.filter(prop => prop.id !== proposalId);
        
        const naoRetornadoSheetProposals = [...(newState[SHEET_NAME_SALDOS_NAO_RETORNADOS] || [])];
        naoRetornadoSheetProposals.unshift(proposalToUpdate); 
        newState[SHEET_NAME_SALDOS_NAO_RETORNADOS] = naoRetornadoSheetProposals;

        addNotification('success', `Proposta ${proposalToUpdate.numeroProposta} movida para ${SHEET_NAME_SALDOS_NAO_RETORNADOS}.`);

      } else if (sheetName === SHEET_NAME_CONTRATOS_NOVOS_REFIN && (effectiveNewStatus === ProposalStatus.PAGO || effectiveNewStatus === ProposalStatus.PAGA)) {
        proposalToUpdate.statusProposta = ProposalStatus.PAGO; 
        proposalToUpdate.observacoes = observations;

        newState[sheetName] = sourceSheetProposals.filter(p => p.id !== proposalId);
        
        const paidSheetProposals = [...(newState[SHEET_NAME_CONTRATOS_PAGOS] || [])];
        paidSheetProposals.unshift(proposalToUpdate); 
        newState[SHEET_NAME_CONTRATOS_PAGOS] = paidSheetProposals;

        addNotification('success', `Proposta ${proposalToUpdate.numeroProposta} movida para ${SHEET_NAME_CONTRATOS_PAGOS}.`);
      
      } else {
        proposalToUpdate.statusProposta = effectiveNewStatus;
        proposalToUpdate.observacoes = observations;

        if (sheetName === SHEET_NAME_PORTABILIDADE && effectiveNewStatus === ProposalStatus.SALDO_RETORNADO) {
            const p = proposalToUpdate as PortabilidadeProposal;
            if (!p.dataRetornoCip) { // Set dataRetornoCip if status is SALDO_RETORNADO and it's not set
                p.dataRetornoCip = new Date().toISOString().split('T')[0];
            }
        }
        sourceSheetProposals[proposalIndex] = proposalToUpdate;
        newState[sheetName] = sourceSheetProposals;
        addNotification('info', `Status da proposta ${proposalToUpdate.numeroProposta} atualizado.`);
      }
      return newState;
    });
    setIsStatusModalOpen(false);
    setStatusChangeTarget(null);
  }, [statusChangeTarget, addNotification, handleDeleteProposal]);
  
  const getProposalsForSheet = useCallback((sheetName: string): Proposal[] => {
    return proposalsBySheet[sheetName] || [];
  }, [proposalsBySheet]);


  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header />
      
      <div className="fixed top-20 right-4 z-[100] w-full max-w-sm space-y-2">
        {notifications.map(n => (
          <div key={n.id} className={`p-4 rounded-md shadow-lg text-sm font-medium
            ${n.type === 'success' ? 'bg-green-100 border border-green-400 text-green-700' : ''}
            ${n.type === 'error' ? 'bg-red-100 border border-red-400 text-red-700' : ''}
            ${n.type === 'info' ? 'bg-blue-100 border border-blue-400 text-blue-700' : ''}
            ${n.type === 'warning' ? 'bg-yellow-100 border border-yellow-400 text-yellow-700' : ''}
          `}>
            <i className={`fas ${
                n.type === 'success' ? 'fa-check-circle' : 
                n.type === 'error' ? 'fa-exclamation-circle' : 
                n.type === 'info' ? 'fa-info-circle' : 
                'fa-exclamation-triangle'} mr-2`}></i>
            {n.message}
          </div>
        ))}
      </div>

      <main className="container mx-auto px-4 py-6 flex-grow">
        <FilterBar 
          filters={filters}
          onFilterChange={handleFilterChange}
          onApplyFilters={handleApplyFilters}
          onClearFilters={handleClearFilters}
        />

        <div className="mb-4">
          <button 
            onClick={() => { setEditingProposal(null); setIsAddModalOpen(true); }}
            className="bg-success hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-md shadow-sm flex items-center"
            aria-label="Adicionar Nova Proposta"
          >
            <i className="fas fa-plus mr-2"></i> Adicionar Nova Proposta
          </button>
        </div>

        <ProposalTabs 
          sheetNames={INITIAL_SHEET_NAMES}
          activeSheetName={activeSheetName}
          onTabChange={setActiveSheetName}
          getProposalsForSheet={getProposalsForSheet}
        />
        <ProposalTable 
          sheetName={activeSheetName}
          proposals={displayedProposals}
          onEdit={handleEditProposal}
          onChangeStatus={handleOpenStatusModal}
          // onDelete prop removed from here
        />
      </main>

      <AddProposalModal 
        isOpen={isAddModalOpen}
        onClose={() => { setIsAddModalOpen(false); setEditingProposal(null); }}
        onSave={handleAddOrUpdateProposal}
        editingProposal={editingProposal}
        activeSheetName={activeSheetName}
      />

      {statusChangeTarget && (
        <StatusModal 
            isOpen={isStatusModalOpen}
            onClose={() => { setIsStatusModalOpen(false); setStatusChangeTarget(null); }}
            onSave={handleStatusChangeSave}
            currentStatus={statusChangeTarget.currentStatus}
            currentObservations={statusChangeTarget.currentObservations}
        />
      )}
      <ExportDropdown />
      <footer className="py-4 bg-primary text-white text-center text-sm">
        Gerenciador de Propostas Souzacred &copy; {new Date().getFullYear()}
      </footer>
    </div>
  );
};

export default App;
