import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import FilterBar from './components/FilterBar';
import ProposalTabs from './components/ProposalTabs';
import ProposalTable from './components/ProposalTable';
import AddProposalModal from './components/AddProposalModal';
import StatusModal from './components/StatusModal';
import ExportDropdown from './components/ExportDropdown';
import { Proposal, SheetData, Filters, ContratoNovoRefinProposal, PortabilidadeProposal, OperationType, ProposalStatus, NotificationMessage } from './types'; // Removed BaseProposal as it's not directly used here for typing state.
import { SHEET_NAME_CONTRATOS_NOVOS_REFIN, SHEET_NAME_PORTABILIDADE, INITIAL_SHEET_NAMES } from './constants';
import { generateId, formatBRL } from './utils/formatting'; 

// Initial Mock Data
const initialProposalsData: SheetData = {
  [SHEET_NAME_CONTRATOS_NOVOS_REFIN]: [
    { 
      id: generateId(), dataDigitacao: '2023-01-15', numeroProposta: 'CNREFIN001', cpf: '111.111.111-11', nomeCliente: 'JOÃO DA SILVA', tipoOperacao: OperationType.REFINANCIAMENTO, promotora: 'PROMOTORA A', bancoProponente: 'BANCO PAN', valorParcela: formatBRL('250.00'), valorContrato: formatBRL('10000.00'), statusProposta: ProposalStatus.APROVADA_BANCO, rowClass: 'bg-green-50', observacoes: 'Cliente VIP' 
    } as ContratoNovoRefinProposal,
    { 
      id: generateId(), dataDigitacao: '2023-03-10', numeroProposta: 'CNREFIN002', cpf: '222.222.222-22', nomeCliente: 'MARIA OLIVEIRA', tipoOperacao: OperationType.NOVO, promotora: 'PROMOTORA B', bancoProponente: 'C6 BANK', valorParcela: formatBRL('350.00'), valorContrato: formatBRL('15000.00'), statusProposta: ProposalStatus.AGUARDANDO_AVERBACAO, observacoes: ''
    } as ContratoNovoRefinProposal,
  ],
  [SHEET_NAME_PORTABILIDADE]: [
    { 
      id: generateId(), 
      dataDigitacao: '2023-02-10', 
      dataEnvioCip: '2023-02-11',
      dataRetornoCip: '2023-02-15',
      numeroProposta: 'PORT001', 
      cpf: '333.333.333-33', 
      nomeCliente: 'CARLOS PEREIRA', 
      tipoOperacao: OperationType.PORTABILIDADE, 
      bancoProponente: 'ITAU BMG', 
      promotora: 'PROMOTORA VIP', 
      valorParcela: formatBRL('180.00'), 
      saldoDevedorPrevisto: formatBRL('8000.00'), 
      liquidoPrevisto: formatBRL('7800.00'), 
      saldoRetornado: formatBRL('7950.00'),
      liquidoRecalculado: formatBRL('7750.00'),
      statusProposta: ProposalStatus.AGUARDANDO_SALDO,
      observacoes: 'Aguardando retorno do saldo do banco X.'
    } as PortabilidadeProposal,
    { 
      id: generateId(), 
      dataDigitacao: '2023-04-15', 
      dataEnvioCip: '2023-04-16',
      dataRetornoCip: '', 
      numeroProposta: 'PORT002', 
      cpf: '444.444.444-44', 
      nomeCliente: 'ANA SOUZA', 
      tipoOperacao: OperationType.PORTABILIDADE,
      bancoProponente: 'DAYCOVAL', 
      promotora: 'PROMOTORA A', 
      valorParcela: formatBRL('420.00'), 
      saldoDevedorPrevisto: formatBRL('20000.00'), 
      liquidoPrevisto: formatBRL('19500.00'), 
      saldoRetornado: formatBRL('19800.00'), // saldo retornado even if not used in some views
      liquidoRecalculado: formatBRL('19300.00'), // liquido recalculado
      statusProposta: ProposalStatus.SALDO_RETORNADO, 
      rowClass: 'bg-blue-50',
      observacoes: 'Saldo retornado, pendente aceite cliente.'
    } as PortabilidadeProposal,
  ]
};

const App: React.FC = () => {
  const [proposalsBySheet, setProposalsBySheet] = useState<SheetData>(initialProposalsData);
  const [activeSheetName, setActiveSheetName] = useState<string>(INITIAL_SHEET_NAMES[0]);
  const [filters, setFilters] = useState<Filters>({ nomeCliente: '', cpf: '', banco: '', promotora: '' });
  const [displayedProposals, setDisplayedProposals] = useState<Proposal[]>([]);

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProposal, setEditingProposal] = useState<Proposal | null>(null);

  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false);
  const [statusChangeTarget, setStatusChangeTarget] = useState<{ proposalId: string; sheetName: string; currentStatus?: string; currentObservations?: string } | null>(null);
  
  const [notifications, setNotifications] = useState<NotificationMessage[]>([]);

  const addNotification = (type: NotificationMessage['type'], message: string) => {
    const newNotification = { id: generateId(), type, message };
    setNotifications(prev => [newNotification, ...prev.slice(0,2)]); // Keep max 3 notifications
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== newNotification.id));
    }, 5000);
  };

  const applyFilters = useCallback(() => {
    const currentSheetProposals = proposalsBySheet[activeSheetName] || [];
    const filtered = currentSheetProposals.filter(p => {
      const nomeClienteMatch = !filters.nomeCliente || p.nomeCliente.toLowerCase().includes(filters.nomeCliente.toLowerCase());
      const cpfMatch = !filters.cpf || p.cpf.includes(filters.cpf); // Assuming CPF filter is for partial match on formatted CPF
      const bancoMatch = !filters.banco || p.bancoProponente === filters.banco;
      const promotoraMatch = !filters.promotora || p.promotora === filters.promotora;
      return nomeClienteMatch && cpfMatch && bancoMatch && promotoraMatch;
    });
    setDisplayedProposals(filtered);
  }, [proposalsBySheet, activeSheetName, filters]);

  useEffect(() => {
    applyFilters();
  }, [applyFilters]);

  const handleFilterChange = <K extends keyof Filters>(key: K, value: Filters[K]) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleApplyFilters = () => {
    applyFilters(); 
  };

  const handleClearFilters = () => {
    setFilters({ nomeCliente: '', cpf: '', banco: '', promotora: '' });
    // applyFilters will be called by useEffect due to filters change, 
    // or call it explicitly if direct update is preferred: applyFilters();
  };

  const handleAddOrUpdateProposal = (proposal: Proposal, sheetName: string) => {
    setProposalsBySheet(prev => {
      const sheetProposals = [...(prev[sheetName] || [])];
      const existingIndex = sheetProposals.findIndex(p => p.id === proposal.id);
      if (existingIndex > -1) {
        sheetProposals[existingIndex] = proposal; 
         addNotification('success', `Proposta ${proposal.numeroProposta} atualizada com sucesso!`);
      } else {
        sheetProposals.unshift(proposal); // Add new proposals to the top
        addNotification('success', `Proposta ${proposal.numeroProposta} adicionada com sucesso!`);
      }
      return { ...prev, [sheetName]: sheetProposals };
    });
    setEditingProposal(null); // Clear editing state
    setIsAddModalOpen(false); // Close modal
  };
  
  const handleEditProposal = (proposal: Proposal) => {
    // Ensure the proposal object being set for editing is a fresh copy 
    // to avoid direct state mutation issues if it were passed around and modified elsewhere.
    let proposalToEdit = { ...proposal }; 
    setEditingProposal(proposalToEdit);
    setIsAddModalOpen(true);
  };

  const handleOpenStatusModal = (proposalId: string, sheetName: string) => {
     const proposal = proposalsBySheet[sheetName]?.find(p => p.id === proposalId);
     if (proposal) {
        setStatusChangeTarget({ proposalId, sheetName, currentStatus: proposal.statusProposta, currentObservations: proposal.observacoes });
        setIsStatusModalOpen(true);
     }
  };

  const handleStatusChangeSave = (newStatus: string, observations: string, action?: 'delete_proposal' | 'nao_retornado' | 'retornado') => {
    if (!statusChangeTarget) return;
    const { proposalId, sheetName } = statusChangeTarget;

    setProposalsBySheet(prev => {
      const sheetProposals = [...(prev[sheetName] || [])];
      if (action === 'delete_proposal') {
        const proposalToDelete = sheetProposals.find(p => p.id === proposalId);
        const updatedProposals = sheetProposals.filter(p => p.id !== proposalId);
        if (proposalToDelete) addNotification('warning', `Proposta ${proposalToDelete.numeroProposta} excluída.`);
        else addNotification('warning', `Proposta excluída.`);
        return { ...prev, [sheetName]: updatedProposals };
      }
      
      const proposalIndex = sheetProposals.findIndex(p => p.id === proposalId);
      if (proposalIndex > -1) {
        const updatedProposal = { 
          ...sheetProposals[proposalIndex], 
          statusProposta: newStatus || sheetProposals[proposalIndex].statusProposta, 
          observacoes: observations 
        };
        // Specific logic for SALDO_RETORNADO / SALDO_NAO_RETORNADO impacting dates or other fields
        if (sheetName === SHEET_NAME_PORTABILIDADE) {
            const p = updatedProposal as PortabilidadeProposal;
            if (newStatus === ProposalStatus.SALDO_RETORNADO && !p.dataRetornoCip) {
                p.dataRetornoCip = new Date().toISOString().split('T')[0];
            }
            // If status changes from AGUARDANDO_SALDO and dataEnvioCip is not set, set it.
            if (sheetProposals[proposalIndex].statusProposta === ProposalStatus.AGUARDANDO_SALDO && 
                (newStatus === ProposalStatus.SALDO_NAO_RETORNADO || newStatus === ProposalStatus.SALDO_RETORNADO) &&
                !p.dataEnvioCip && p.dataDigitacao) {
                   // This logic might be better placed in AddProposalModal or a dedicated service
                   // For now, let's assume dataEnvioCip is handled during creation or edit.
            }
        }

        sheetProposals[proposalIndex] = updatedProposal;
        addNotification('info', `Status da proposta ${sheetProposals[proposalIndex].numeroProposta} atualizado.`);
      }
      return { ...prev, [sheetName]: sheetProposals };
    });
    setIsStatusModalOpen(false);
    setStatusChangeTarget(null);
  };
  
  const getProposalsForSheet = useCallback((sheetName: string): Proposal[] => {
    return proposalsBySheet[sheetName] || [];
  }, [proposalsBySheet]);


  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header />
      
      {/* Notification Area */}
      <div className="fixed top-20 right-4 z-[100] w-full max-w-sm space-y-2">
        {notifications.map(n => (
          <div key={n.id} className={`p-4 rounded-md shadow-lg text-sm font-medium
            ${n.type === 'success' ? 'bg-green-100 border border-green-400 text-green-700' : ''}
            ${n.type === 'error' ? 'bg-red-100 border border-red-400 text-red-700' : ''}
            ${n.type === 'info' ? 'bg-blue-100 border border-blue-400 text-blue-700' : ''}
            ${n.type === 'warning' ? 'bg-yellow-100 border border-yellow-400 text-yellow-700' : ''}
          `}>
            <i className={`fas ${
                n.type === 'success' ? 'fa-check-circle' : 
                n.type === 'error' ? 'fa-exclamation-circle' : 
                n.type === 'info' ? 'fa-info-circle' : 
                'fa-exclamation-triangle'} mr-2`}></i>
            {n.message}
          </div>
        ))}
      </div>

      <main className="container mx-auto px-4 py-6 flex-grow">
        <FilterBar 
          filters={filters}
          onFilterChange={handleFilterChange}
          onApplyFilters={handleApplyFilters}
          onClearFilters={handleClearFilters}
        />

        <div className="mb-4">
          <button 
            onClick={() => { setEditingProposal(null); setIsAddModalOpen(true); }}
            className="bg-success hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-md shadow-sm flex items-center"
            aria-label="Adicionar Nova Proposta"
          >
            <i className="fas fa-plus mr-2"></i> Adicionar Nova Proposta
          </button>
        </div>

        <ProposalTabs 
          sheetNames={INITIAL_SHEET_NAMES}
          activeSheetName={activeSheetName}
          onTabChange={setActiveSheetName}
          getProposalsForSheet={getProposalsForSheet}
        />
        <ProposalTable 
          sheetName={activeSheetName}
          proposals={displayedProposals}
          onEdit={handleEditProposal}
          onChangeStatus={handleOpenStatusModal}
        />
      </main>

      <AddProposalModal 
        isOpen={isAddModalOpen}
        onClose={() => { setIsAddModalOpen(false); setEditingProposal(null); }}
        onSave={handleAddOrUpdateProposal}
        editingProposal={editingProposal}
        activeSheetName={activeSheetName}
      />

      {statusChangeTarget && (
        <StatusModal 
            isOpen={isStatusModalOpen}
            onClose={() => { setIsStatusModalOpen(false); setStatusChangeTarget(null); }}
            onSave={handleStatusChangeSave}
            currentStatus={statusChangeTarget.currentStatus}
            currentObservations={statusChangeTarget.currentObservations}
        />
      )}
      <ExportDropdown />
      <footer className="py-4 bg-primary text-white text-center text-sm">
        Gerenciador de Propostas INSS &copy; {new Date().getFullYear()}
      </footer>
    </div>
  );
};

export default App;
