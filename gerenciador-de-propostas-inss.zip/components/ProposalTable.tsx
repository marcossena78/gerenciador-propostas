
import React from 'react';
import { Proposal, ContratoNovoRefinProposal, PortabilidadeProposal } from '../types';
import { SHEET_NAME_CONTRATOS_NOVOS_REFIN, COLUMNS_CONTRATOS_NOVOS_REFIN, COLUMNS_PORTABILIDADE } from '../constants';

interface ProposalTableProps {
  sheetName: string;
  proposals: Proposal[];
  onEdit: (proposal: Proposal) => void;
  onChangeStatus: (proposalId: string, sheetName: string) => void;
}

const ProposalTable: React.FC<ProposalTableProps> = ({ sheetName, proposals, onEdit, onChangeStatus }) => {
  const columns = sheetName === SHEET_NAME_CONTRATOS_NOVOS_REFIN ? COLUMNS_CONTRATOS_NOVOS_REFIN : COLUMNS_PORTABILIDADE;

  const renderCellContent = (proposal: Proposal, columnKey: string): React.ReactNode => {
    // Type guard to access specific properties
    if (sheetName === SHEET_NAME_CONTRATOS_NOVOS_REFIN) {
      const p = proposal as ContratoNovoRefinProposal;
      return p[columnKey as keyof ContratoNovoRefinProposal] || '';
    } else {
      const p = proposal as PortabilidadeProposal;
      return p[columnKey as keyof PortabilidadeProposal] || '';
    }
  };

  return (
    <div className="overflow-x-auto bg-white shadow-md rounded-b-lg">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-dark text-white">
          <tr>
            {columns.map(col => (
              <th key={col.key} scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">
                {col.label}
              </th>
            ))}
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">
              Ações
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {proposals.length === 0 ? (
            <tr>
              <td colSpan={columns.length + 1} className="px-6 py-12 text-center text-gray-500 text-lg">
                <i className="fas fa-folder-open fa-3x mb-3 text-gray-400"></i>
                <p>Nenhuma proposta encontrada para os filtros aplicados.</p>
              </td>
            </tr>
          ) : (
            proposals.map((proposal) => (
              <tr key={proposal.id} className={`hover:bg-gray-50 transition-colors ${proposal.rowClass || ''}`}>
                {columns.map(col => (
                  <td key={col.key} className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                    {renderCellContent(proposal, col.key)}
                  </td>
                ))}
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => onEdit(proposal)}
                      className="text-primary hover:text-blue-700 transition-colors"
                      title="Editar Proposta"
                    >
                      <i className="fas fa-edit"></i>
                    </button>
                    <button
                      onClick={() => onChangeStatus(proposal.id, sheetName)}
                      className="text-info hover:text-cyan-700 transition-colors"
                      title="Alterar Status"
                    >
                      <i className="fas fa-exchange-alt"></i>
                    </button>
                  </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ProposalTable;
    